import Link from 'next/link'
import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Pricing - OurProduct',
  description: 'Simple, transparent pricing that scales with your business',
}

const tiers = [
  {
    name: 'Starter',
    price: '$0',
    description: 'Perfect for side projects and experimentation',
    features: [
      '10 projects',
      '100GB bandwidth',
      'Community support',
      'Basic analytics',
      '99.9% uptime SLA',
    ],
    cta: 'Start Free',
    href: '/signup',
    featured: false,
  },
  {
    name: 'Pro',
    price: '$49',
    description: 'For professional developers and small teams',
    features: [
      'Unlimited projects',
      '1TB bandwidth',
      'Priority support',
      'Advanced analytics',
      '99.99% uptime SLA',
      'Custom domains',
      'Team collaboration',
      'API access',
    ],
    cta: 'Start Pro Trial',
    href: '/signup?plan=pro',
    featured: true,
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    description: 'For large teams with advanced requirements',
    features: [
      'Everything in Pro',
      'Unlimited bandwidth',
      'Dedicated support',
      'Custom SLAs',
      'SSO & SAML',
      'Advanced security',
      'Compliance (SOC 2, HIPAA)',
      'Custom contracts',
    ],
    cta: 'Contact Sales',
    href: '/contact',
    featured: false,
  },
]

const faqs = [
  {
    question: 'Can I change plans later?',
    answer: 'Yes, you can upgrade or downgrade at any time. Changes take effect immediately.',
  },
  {
    question: 'What payment methods do you accept?',
    answer: 'We accept all major credit cards, PayPal, and can provide invoicing for annual plans.',
  },
  {
    question: 'Is there a free trial?',
    answer: 'Pro plans include a 14-day free trial with no credit card required. Cancel anytime.',
  },
  {
    question: 'What happens if I exceed my limits?',
    answer: 'We\'ll notify you before you hit limits. You can upgrade or purchase additional resources.',
  },
  {
    question: 'Do you offer discounts for nonprofits?',
    answer: 'Yes, we offer 50% discounts for registered nonprofits and educational institutions.',
  },
  {
    question: 'Can I pay annually?',
    answer: 'Yes, annual plans receive a 20% discount. Contact sales for custom annual agreements.',
  },
]

export default function PricingPage() {
  return (
    <div className="min-h-screen pt-24 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-xl text-dark-text-secondary max-w-3xl mx-auto">
            Start free, scale as you grow. No hidden fees or surprise charges.
          </p>
        </div>

        {/* Pricing Tiers */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {tiers.map((tier) => (
            <div
              key={tier.name}
              className={`relative bg-dark-surface border rounded-lg p-8 ${
                tier.featured
                  ? 'border-white shadow-lg shadow-white/10'
                  : 'border-dark-border'
              }`}
            >
              {tier.featured && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-white text-black text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">
                    Most Popular
                  </span>
                </div>
              )}

              <div className="mb-8">
                <h2 className="text-2xl font-bold mb-2">{tier.name}</h2>
                <div className="flex items-baseline mb-2">
                  <span className="text-5xl font-bold">{tier.price}</span>
                  {tier.price !== 'Custom' && (
                    <span className="text-dark-text-secondary ml-2">/month</span>
                  )}
                </div>
                <p className="text-dark-text-secondary">{tier.description}</p>
              </div>

              <ul className="space-y-4 mb-8">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-start">
                    <svg
                      className="h-6 w-6 text-white mr-3 flex-shrink-0"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                    <span className="text-dark-text-secondary">{feature}</span>
                  </li>
                ))}
              </ul>

              <Link
                href={tier.href}
                className={`block w-full text-center py-3 rounded-md font-medium transition-all ${
                  tier.featured
                    ? 'bg-white text-black hover:bg-gray-200'
                    : 'border border-white text-white hover:bg-white hover:text-black'
                }`}
              >
                {tier.cta}
              </Link>
            </div>
          ))}
        </div>

        {/* Enterprise Features */}
        <div className="bg-dark-surface border border-dark-border rounded-lg p-12 mb-20">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Enterprise-Grade Platform</h2>
            <p className="text-lg text-dark-text-secondary mb-8">
              Get dedicated support, custom SLAs, and advanced security features for your organization
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
              <div>
                <div className="text-3xl font-bold mb-1">99.99%</div>
                <div className="text-sm text-dark-text-secondary">Uptime SLA</div>
              </div>
              <div>
                <div className="text-3xl font-bold mb-1">&lt;50ms</div>
                <div className="text-sm text-dark-text-secondary">Avg Latency</div>
              </div>
              <div>
                <div className="text-3xl font-bold mb-1">24/7</div>
                <div className="text-sm text-dark-text-secondary">Support</div>
              </div>
              <div>
                <div className="text-3xl font-bold mb-1">SOC 2</div>
                <div className="text-sm text-dark-text-secondary">Certified</div>
              </div>
            </div>
            <Link
              href="/contact"
              className="inline-flex items-center btn-primary rounded-md"
            >
              Talk to Sales
              <svg className="ml-2 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
        </div>

        {/* FAQ */}
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-center">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {faqs.map((faq) => (
              <div key={faq.question} className="border-b border-dark-border pb-6">
                <h3 className="text-lg font-bold mb-2">{faq.question}</h3>
                <p className="text-dark-text-secondary">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
