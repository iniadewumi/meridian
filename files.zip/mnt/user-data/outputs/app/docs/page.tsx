import Link from 'next/link'
import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Documentation - OurProduct',
  description: 'Complete documentation, guides, and API reference for OurProduct',
}

const docSections = [
  {
    title: 'Getting Started',
    description: 'Quick start guides to get up and running in minutes',
    links: [
      { name: 'Installation', href: '/docs/installation' },
      { name: 'Quick Start', href: '/docs/quickstart' },
      { name: 'Configuration', href: '/docs/configuration' },
      { name: 'First Project', href: '/docs/first-project' },
    ],
  },
  {
    title: 'Core Concepts',
    description: 'Understand the fundamental concepts and architecture',
    links: [
      { name: 'Architecture', href: '/docs/architecture' },
      { name: 'Data Models', href: '/docs/data-models' },
      { name: 'Authentication', href: '/docs/authentication' },
      { name: 'API Overview', href: '/docs/api-overview' },
    ],
  },
  {
    title: 'Guides',
    description: 'Step-by-step tutorials for common use cases',
    links: [
      { name: 'Building APIs', href: '/docs/guides/building-apis' },
      { name: 'Database Integration', href: '/docs/guides/database' },
      { name: 'Deployment', href: '/docs/guides/deployment' },
      { name: 'Best Practices', href: '/docs/guides/best-practices' },
    ],
  },
  {
    title: 'API Reference',
    description: 'Complete API documentation and SDK reference',
    links: [
      { name: 'REST API', href: '/docs/api/rest' },
      { name: 'JavaScript SDK', href: '/docs/api/javascript' },
      { name: 'Python SDK', href: '/docs/api/python' },
      { name: 'CLI Reference', href: '/docs/api/cli' },
    ],
  },
]

export default function DocsPage() {
  return (
    <div className="min-h-screen pt-24 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-16">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-4">
            Documentation
          </h1>
          <p className="text-xl text-dark-text-secondary max-w-3xl">
            Everything you need to build, deploy, and scale your applications with OurProduct
          </p>
        </div>

        {/* Search Bar */}
        <div className="mb-16">
          <div className="relative max-w-2xl">
            <input
              type="text"
              placeholder="Search documentation..."
              className="w-full bg-dark-surface border border-dark-border rounded-lg px-4 py-3 pl-12 text-white placeholder-dark-text-muted focus:outline-none focus:ring-2 focus:ring-white focus:border-transparent"
            />
            <svg
              className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-dark-text-muted"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
          </div>
        </div>

        {/* Documentation Sections */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {docSections.map((section) => (
            <div
              key={section.title}
              className="bg-dark-surface border border-dark-border rounded-lg p-8"
            >
              <h2 className="text-2xl font-bold mb-2">{section.title}</h2>
              <p className="text-dark-text-secondary mb-6">{section.description}</p>
              <ul className="space-y-3">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-dark-text-secondary hover:text-white transition-colors inline-flex items-center group"
                    >
                      <span className="group-hover:underline">{link.name}</span>
                      <svg
                        className="ml-2 h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Popular Resources */}
        <div className="mt-16 pt-16 border-t border-dark-border">
          <h2 className="text-2xl font-bold mb-8">Popular Resources</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Link
              href="/docs/quickstart"
              className="bg-dark-surface border border-dark-border rounded-lg p-6 hover:border-dark-text-muted transition-all"
            >
              <h3 className="font-bold mb-2">5-Minute Quickstart</h3>
              <p className="text-sm text-dark-text-secondary">
                Get your first application running in under 5 minutes
              </p>
            </Link>
            <Link
              href="/docs/examples"
              className="bg-dark-surface border border-dark-border rounded-lg p-6 hover:border-dark-text-muted transition-all"
            >
              <h3 className="font-bold mb-2">Example Projects</h3>
              <p className="text-sm text-dark-text-secondary">
                Browse complete example applications and templates
              </p>
            </Link>
            <Link
              href="/docs/migration"
              className="bg-dark-surface border border-dark-border rounded-lg p-6 hover:border-dark-text-muted transition-all"
            >
              <h3 className="font-bold mb-2">Migration Guides</h3>
              <p className="text-sm text-dark-text-secondary">
                Moving from another platform? We've got you covered
              </p>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
