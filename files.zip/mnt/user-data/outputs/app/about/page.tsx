import { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'About - OurProduct',
  description: 'Learn about our mission, team, and commitment to building the future of development',
}

const team = [
  {
    name: 'Jane Smith',
    role: 'CEO & Co-Founder',
    bio: 'Previously led engineering at TechCorp. Stanford CS.',
  },
  {
    name: 'John Doe',
    role: 'CTO & Co-Founder',
    bio: 'Built infrastructure for 1B+ users. MIT grad.',
  },
  {
    name: 'Sarah Johnson',
    role: 'VP Engineering',
    bio: 'Former Principal Engineer at BigTech. Berkeley CS.',
  },
  {
    name: 'Mike Wilson',
    role: 'VP Product',
    bio: '15 years building developer tools. Y Combinator alum.',
  },
]

const values = [
  {
    title: 'Developer First',
    description: 'Everything we build starts with the developer experience. If it\'s not delightful to use, we don\'t ship it.',
  },
  {
    title: 'Performance Obsessed',
    description: 'Speed matters. We measure every millisecond and optimize relentlessly to give your users the best experience.',
  },
  {
    title: 'Security by Default',
    description: 'Security isn\'t a feature—it\'s a foundation. Every component is built with security best practices from day one.',
  },
  {
    title: 'Open & Transparent',
    description: 'We believe in building in public, sharing our learnings, and contributing back to the open source community.',
  },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen pt-24 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-20">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-4">
            Building the Future of Development
          </h1>
          <p className="text-xl text-dark-text-secondary max-w-3xl mx-auto">
            We're on a mission to empower developers to build faster, scale easier, and ship with confidence
          </p>
        </div>

        {/* Story */}
        <div className="max-w-3xl mx-auto mb-20">
          <h2 className="text-3xl font-bold mb-6">Our Story</h2>
          <div className="space-y-4 text-dark-text-secondary leading-relaxed">
            <p>
              OurProduct was born from a simple frustration: building modern applications was too complex,
              too slow, and too expensive. We spent years at leading tech companies watching talented teams
              struggle with infrastructure complexity instead of solving customer problems.
            </p>
            <p>
              In 2022, we set out to change that. We started with a question: what if developers could ship
              production-ready applications in hours instead of months? What if infrastructure just worked,
              security was built-in, and scaling was automatic?
            </p>
            <p>
              Today, OurProduct powers thousands of applications serving millions of users worldwide. From
              startups to Fortune 500 companies, developers trust us to handle the complexity so they can
              focus on what matters: building great products.
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20">
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">10K+</div>
            <div className="text-sm text-dark-text-secondary">Active Projects</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">100M+</div>
            <div className="text-sm text-dark-text-secondary">API Requests Daily</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">99.99%</div>
            <div className="text-sm text-dark-text-secondary">Uptime SLA</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">150+</div>
            <div className="text-sm text-dark-text-secondary">Countries</div>
          </div>
        </div>

        {/* Values */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold mb-12 text-center">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value) => (
              <div key={value.title} className="bg-dark-surface border border-dark-border rounded-lg p-8">
                <h3 className="text-xl font-bold mb-3">{value.title}</h3>
                <p className="text-dark-text-secondary">{value.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Team */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold mb-12 text-center">Leadership Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {team.map((member) => (
              <div key={member.name} className="text-center">
                <div className="w-32 h-32 bg-dark-surface border border-dark-border rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-3xl font-bold text-dark-text-muted">
                    {member.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
                <h3 className="font-bold mb-1">{member.name}</h3>
                <p className="text-sm text-dark-text-secondary mb-2">{member.role}</p>
                <p className="text-xs text-dark-text-muted">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Backed By */}
        <div className="mb-20 text-center">
          <h2 className="text-3xl font-bold mb-8">Backed by Leading Investors</h2>
          <div className="flex flex-wrap justify-center items-center gap-12 text-dark-text-secondary">
            <div className="text-lg font-semibold">Sequoia Capital</div>
            <div className="text-lg font-semibold">Andreessen Horowitz</div>
            <div className="text-lg font-semibold">Index Ventures</div>
            <div className="text-lg font-semibold">Y Combinator</div>
          </div>
        </div>

        {/* Careers CTA */}
        <div className="bg-dark-surface border border-dark-border rounded-lg p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">Join Our Team</h2>
          <p className="text-lg text-dark-text-secondary mb-8 max-w-2xl mx-auto">
            We're always looking for talented people who share our passion for building great products
          </p>
          <Link
            href="/careers"
            className="btn-primary rounded-md inline-flex items-center"
          >
            View Open Positions
            <svg className="ml-2 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        </div>
      </div>
    </div>
  )
}
