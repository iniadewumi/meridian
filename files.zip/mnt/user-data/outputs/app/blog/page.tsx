import Link from 'next/link'
import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Blog - OurProduct',
  description: 'Latest news, updates, and technical insights from the OurProduct team',
}

// Mock blog posts - replace with actual CMS or API data
const blogPosts = [
  {
    title: 'Introducing OurProduct 2.0: Faster, Stronger, Better',
    excerpt: 'Today we\'re excited to announce OurProduct 2.0, our biggest release yet with 10x performance improvements and new enterprise features.',
    date: '2025-01-15',
    author: 'Jane Smith',
    category: 'Product',
    readTime: '5 min read',
    slug: 'introducing-v2',
  },
  {
    title: 'How We Achieve 99.99% Uptime at Scale',
    excerpt: 'A deep dive into our infrastructure, monitoring, and deployment strategies that power mission-critical applications.',
    date: '2025-01-10',
    author: 'John Doe',
    category: 'Engineering',
    readTime: '8 min read',
    slug: 'uptime-at-scale',
  },
  {
    title: 'Building Secure Applications: Best Practices Guide',
    excerpt: 'Learn how to implement security best practices from day one, including authentication, authorization, and data protection.',
    date: '2025-01-05',
    author: 'Sarah Johnson',
    category: 'Security',
    readTime: '12 min read',
    slug: 'security-best-practices',
  },
  {
    title: 'Case Study: How TechCorp Scaled to 10M Users',
    excerpt: 'Learn how TechCorp used OurProduct to handle massive traffic spikes during their biggest sales event.',
    date: '2025-01-01',
    author: 'Mike Wilson',
    category: 'Case Study',
    readTime: '6 min read',
    slug: 'techcorp-case-study',
  },
  {
    title: 'Performance Optimization Tips for Production Apps',
    excerpt: 'Practical tips and tricks to optimize your application performance, from database queries to CDN configuration.',
    date: '2024-12-28',
    author: 'Emily Chen',
    category: 'Performance',
    readTime: '10 min read',
    slug: 'performance-optimization',
  },
  {
    title: 'Year in Review: 2024 Highlights',
    excerpt: 'Looking back at an incredible year of growth, new features, and amazing customer success stories.',
    date: '2024-12-20',
    author: 'Jane Smith',
    category: 'Company',
    readTime: '4 min read',
    slug: 'year-in-review-2024',
  },
]

const categories = ['All', 'Product', 'Engineering', 'Security', 'Case Study', 'Performance', 'Company']

export default function BlogPage() {
  return (
    <div className="min-h-screen pt-24 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-16">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-4">
            Blog
          </h1>
          <p className="text-xl text-dark-text-secondary max-w-3xl">
            Latest news, product updates, and technical insights from the OurProduct team
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-3 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                category === 'All'
                  ? 'bg-white text-black'
                  : 'bg-dark-surface text-dark-text-secondary hover:text-white border border-dark-border hover:border-dark-text-muted'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Featured Post */}
        <Link
          href={`/blog/${blogPosts[0].slug}`}
          className="block bg-dark-surface border border-dark-border rounded-lg overflow-hidden mb-12 hover:border-dark-text-muted transition-all group"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-8">
            <div className="aspect-video bg-dark-border rounded-lg flex items-center justify-center">
              <span className="text-dark-text-muted text-sm">Featured Image</span>
            </div>
            <div className="flex flex-col justify-center">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-xs uppercase tracking-wider text-dark-text-muted bg-dark-border px-2 py-1 rounded">
                  {blogPosts[0].category}
                </span>
                <span className="text-xs text-dark-text-muted">{blogPosts[0].readTime}</span>
              </div>
              <h2 className="text-3xl font-bold mb-3 group-hover:text-dark-text-secondary transition-colors">
                {blogPosts[0].title}
              </h2>
              <p className="text-dark-text-secondary mb-4">{blogPosts[0].excerpt}</p>
              <div className="flex items-center gap-2 text-sm text-dark-text-muted">
                <span>{blogPosts[0].author}</span>
                <span>•</span>
                <time>{new Date(blogPosts[0].date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</time>
              </div>
            </div>
          </div>
        </Link>

        {/* Blog Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {blogPosts.slice(1).map((post) => (
            <Link
              key={post.slug}
              href={`/blog/${post.slug}`}
              className="group bg-dark-surface border border-dark-border rounded-lg overflow-hidden hover:border-dark-text-muted transition-all"
            >
              {/* Image Placeholder */}
              <div className="aspect-video bg-dark-border flex items-center justify-center">
                <span className="text-dark-text-muted text-sm">Post Image</span>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-xs uppercase tracking-wider text-dark-text-muted bg-dark-border px-2 py-1 rounded">
                    {post.category}
                  </span>
                  <span className="text-xs text-dark-text-muted">{post.readTime}</span>
                </div>

                <h3 className="text-xl font-bold mb-2 group-hover:text-dark-text-secondary transition-colors">
                  {post.title}
                </h3>

                <p className="text-sm text-dark-text-secondary mb-4 line-clamp-3">
                  {post.excerpt}
                </p>

                <div className="flex items-center gap-2 text-xs text-dark-text-muted">
                  <span>{post.author}</span>
                  <span>•</span>
                  <time>{new Date(post.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</time>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Newsletter Signup */}
        <div className="mt-20 bg-dark-surface border border-dark-border rounded-lg p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">Subscribe to Our Newsletter</h2>
          <p className="text-lg text-dark-text-secondary mb-8 max-w-2xl mx-auto">
            Get the latest product updates, technical articles, and company news delivered to your inbox
          </p>
          <form className="max-w-md mx-auto flex gap-3">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 bg-dark-bg border border-dark-border rounded-md px-4 py-3 text-white placeholder-dark-text-muted focus:outline-none focus:ring-2 focus:ring-white focus:border-transparent"
              required
            />
            <button
              type="submit"
              className="btn-primary rounded-md px-6 whitespace-nowrap"
            >
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
