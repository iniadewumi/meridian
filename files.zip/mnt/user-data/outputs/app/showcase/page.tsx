import Image from 'next/image'
import Link from 'next/link'
import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Showcase - OurProduct',
  description: 'See how leading companies use OurProduct to build and scale their applications',
}

const showcases = [
  {
    company: 'TechCorp',
    logo: '/logos/techcorp.svg',
    tagline: 'E-commerce Platform',
    description: 'TechCorp scaled their platform to handle 10M+ daily users with zero downtime during peak sales events.',
    metrics: [
      { label: 'Uptime', value: '100%' },
      { label: 'Load Time', value: '1.2s' },
      { label: 'Daily Users', value: '10M+' },
    ],
    image: '/showcase/techcorp.jpg',
    href: '/showcase/techcorp',
  },
  {
    company: 'FinanceApp',
    logo: '/logos/financeapp.svg',
    tagline: 'Financial Services',
    description: 'Achieved SOC 2 compliance and reduced infrastructure costs by 60% while improving performance.',
    metrics: [
      { label: 'Cost Savings', value: '60%' },
      { label: 'API Latency', value: '<50ms' },
      { label: 'Compliance', value: 'SOC 2' },
    ],
    image: '/showcase/financeapp.jpg',
    href: '/showcase/financeapp',
  },
  {
    company: 'HealthTech',
    logo: '/logos/healthtech.svg',
    tagline: 'Healthcare Platform',
    description: 'Built a HIPAA-compliant telehealth platform serving 500K+ patients with real-time video consultations.',
    metrics: [
      { label: 'Patients', value: '500K+' },
      { label: 'Video Quality', value: '1080p' },
      { label: 'Compliance', value: 'HIPAA' },
    ],
    image: '/showcase/healthtech.jpg',
    href: '/showcase/healthtech',
  },
  {
    company: 'MediaStream',
    logo: '/logos/mediastream.svg',
    tagline: 'Video Streaming',
    description: 'Delivers 4K video content to millions of concurrent viewers with 99.99% uptime.',
    metrics: [
      { label: 'Concurrent Users', value: '2M+' },
      { label: 'CDN Coverage', value: 'Global' },
      { label: 'Uptime', value: '99.99%' },
    ],
    image: '/showcase/mediastream.jpg',
    href: '/showcase/mediastream',
  },
  {
    company: 'EdTech Solutions',
    logo: '/logos/edtech.svg',
    tagline: 'Education Platform',
    description: 'Powers online learning for 1M+ students with real-time collaboration and interactive content.',
    metrics: [
      { label: 'Students', value: '1M+' },
      { label: 'Response Time', value: '<100ms' },
      { label: 'Satisfaction', value: '4.8/5' },
    ],
    image: '/showcase/edtech.jpg',
    href: '/showcase/edtech',
  },
  {
    company: 'RetailChain',
    logo: '/logos/retailchain.svg',
    tagline: 'Retail & Logistics',
    description: 'Modernized inventory management across 500+ locations with real-time synchronization.',
    metrics: [
      { label: 'Locations', value: '500+' },
      { label: 'Sync Speed', value: 'Real-time' },
      { label: 'Accuracy', value: '99.9%' },
    ],
    image: '/showcase/retailchain.jpg',
    href: '/showcase/retailchain',
  },
]

const categories = [
  'All',
  'E-commerce',
  'Financial Services',
  'Healthcare',
  'Media',
  'Education',
  'Enterprise',
]

export default function ShowcasePage() {
  return (
    <div className="min-h-screen pt-24 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-4">
            Built by the Best
          </h1>
          <p className="text-xl text-dark-text-secondary max-w-3xl mx-auto">
            See how leading companies across industries use OurProduct to build, scale, and innovate
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                category === 'All'
                  ? 'bg-white text-black'
                  : 'bg-dark-surface text-dark-text-secondary hover:text-white border border-dark-border hover:border-dark-text-muted'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Showcase Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
          {showcases.map((showcase) => (
            <Link
              key={showcase.company}
              href={showcase.href}
              className="group bg-dark-surface border border-dark-border rounded-lg overflow-hidden hover:border-dark-text-muted transition-all"
            >
              {/* Image Placeholder */}
              <div className="aspect-video bg-dark-border flex items-center justify-center">
                <div className="text-center">
                  <div className="text-4xl font-bold mb-2">{showcase.company}</div>
                  <div className="text-sm text-dark-text-muted">{showcase.tagline}</div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-2xl font-bold">{showcase.company}</h3>
                  <span className="text-xs uppercase tracking-wider text-dark-text-muted bg-dark-border px-2 py-1 rounded">
                    {showcase.tagline}
                  </span>
                </div>

                <p className="text-dark-text-secondary mb-6">{showcase.description}</p>

                {/* Metrics */}
                <div className="grid grid-cols-3 gap-4">
                  {showcase.metrics.map((metric) => (
                    <div key={metric.label}>
                      <div className="text-xl font-bold">{metric.value}</div>
                      <div className="text-xs text-dark-text-muted">{metric.label}</div>
                    </div>
                  ))}
                </div>

                {/* Read More Link */}
                <div className="mt-6 flex items-center text-sm text-dark-text-secondary group-hover:text-white transition-colors">
                  <span>Read case study</span>
                  <svg
                    className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* CTA Section */}
        <div className="bg-dark-surface border border-dark-border rounded-lg p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">Join These Leading Companies</h2>
          <p className="text-lg text-dark-text-secondary mb-8 max-w-2xl mx-auto">
            Start building your success story with OurProduct today
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/docs" className="btn-primary rounded-md inline-flex items-center">
              Get Started
              <svg className="ml-2 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
            <Link href="/contact" className="btn-secondary rounded-md">
              Talk to Sales
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
