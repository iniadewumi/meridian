import Hero from '@/components/Hero'
import FeatureStats from '@/components/FeatureStats'
import FeatureGrid from '@/components/FeatureGrid'
import TrustedBy from '@/components/TrustedBy'

export default function HomePage() {
  return (
    <>
      {/* Hero section with primary CTA */}
      <Hero />

      {/* Social proof - logos */}
      <TrustedBy />

      {/* Performance stats */}
      <FeatureStats />

      {/* Core features */}
      <FeatureGrid />

      {/* Final CTA section */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-3xl md:text-5xl font-bold tracking-tight">
            Ready to ship faster?
          </h2>
          <p className="text-lg text-[#888]">
            Join thousands of developers building the future with our platform
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a
              href="/docs"
              className="btn-primary rounded-md inline-flex items-center"
            >
              Start Building
              <svg className="ml-2 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </a>
            <a
              href="/contact"
              className="btn-secondary rounded-md inline-flex items-center"
            >
              Talk to Sales
            </a>
          </div>
        </div>
      </section>
    </>
  )
}
