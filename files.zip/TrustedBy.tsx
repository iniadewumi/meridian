import Image from 'next/image'

interface CompanyLogo {
  name: string
  // Images will be in /public/logos/
  logoPath: string
  width: number
  height: number
}

const companies: CompanyLogo[] = [
  { name: 'Stripe', logoPath: '/logos/stripe.svg', width: 80, height: 32 },
  { name: 'Vercel', logoPath: '/logos/vercel.svg', width: 100, height: 24 },
  { name: 'GitHub', logoPath: '/logos/github.svg', width: 90, height: 28 },
  { name: 'Netflix', logoPath: '/logos/netflix.svg', width: 100, height: 28 },
  { name: 'Spotify', logoPath: '/logos/spotify.svg', width: 100, height: 32 },
  { name: 'Airbnb', logoPath: '/logos/airbnb.svg', width: 90, height: 32 },
]

export default function TrustedBy() {
  return (
    <section className="py-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-12">
          <p className="text-xs uppercase tracking-wider text-[#666] font-semibold">
            Powering the Best Teams
          </p>
        </div>

        {/* Logo grid */}
        <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-8 grayscale opacity-60 hover:opacity-100 hover:grayscale-0 transition-all duration-500">
          {companies.map((company) => (
            <div
              key={company.name}
              className="flex items-center justify-center"
            >
              {/* Placeholder for actual logos - replace with real images */}
              <div
                className="flex items-center justify-center text-[#888] hover:text-white transition-colors"
                style={{ width: company.width, height: company.height }}
              >
                <span className="text-sm font-semibold">{company.name}</span>
              </div>
              {/* Uncomment when you have actual logo files in /public/logos/ */}
              {/* <Image
                src={company.logoPath}
                alt={`${company.name} logo`}
                width={company.width}
                height={company.height}
                className="object-contain"
              /> */}
            </div>
          ))}
        </div>

        {/* Optional: Add link to full showcase */}
        <div className="text-center mt-12">
          <a
            href="/showcase"
            className="text-sm text-[#888] hover:text-white transition-colors inline-flex items-center gap-1"
          >
            View all case studies
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  )
}
