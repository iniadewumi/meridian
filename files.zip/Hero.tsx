import Link from 'next/link'

export default function Hero() {
  return (
    <section className="min-h-screen flex flex-col items-center justify-center text-center px-6 py-20 relative">
      {/* Optional: Subtle background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-black via-[#111] to-black opacity-50 pointer-events-none" aria-hidden="true" />
      
      <div className="relative z-10 max-w-5xl mx-auto space-y-8 animate-fade-in">
        {/* Main Headline */}
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold tracking-tighter text-balance leading-tight">
          The Platform for{' '}
          <span className="text-white">Modern Development</span>
        </h1>

        {/* Subheadline */}
        <p className="text-lg md:text-xl text-[#888] max-w-2xl mx-auto leading-relaxed">
          Blazing-fast, scalable, and developer-friendly. Built for teams that ship with confidence and speed.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
          <Link
            href="/docs"
            className="btn-primary rounded-md inline-flex items-center"
          >
            Get Started
            <svg className="ml-2 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
          
          <Link
            href="/showcase"
            className="btn-secondary rounded-md inline-flex items-center"
          >
            View Showcase
          </Link>
        </div>

        {/* Optional: Supporting visual or stat */}
        <div className="pt-12 text-sm text-[#666]">
          Trusted by thousands of developers worldwide
        </div>
      </div>
    </section>
  )
}
