import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import Header from '@/components/Header'
import Footer from '@/components/Footer'

// Optimized Inter font with subset and display swap
const inter = Inter({ 
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
})

export const metadata: Metadata = {
  title: 'OurProduct - The Platform for Modern Development',
  description: 'Blazing-fast, scalable, and developer-friendly platform built for the modern web.',
  metadataBase: new URL('https://yoursite.com'),
  openGraph: {
    title: 'OurProduct - The Platform for Modern Development',
    description: 'Blazing-fast, scalable, and developer-friendly platform built for the modern web.',
    type: 'website',
    siteName: 'OurProduct',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'OurProduct - The Platform for Modern Development',
    description: 'Blazing-fast, scalable, and developer-friendly platform built for the modern web.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={inter.variable}>
      <body className={`${inter.className} antialiased`}>
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  )
}
