import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <div className="text-center">
        <h1 className="text-9xl font-bold mb-4">404</h1>
        <h2 className="text-3xl font-bold mb-4">Page Not Found</h2>
        <p className="text-lg text-dark-text-secondary mb-8 max-w-md mx-auto">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/"
            className="btn-primary rounded-md inline-flex items-center justify-center"
          >
            Back to Home
          </Link>
          <Link
            href="/docs"
            className="btn-secondary rounded-md inline-flex items-center justify-center"
          >
            Browse Docs
          </Link>
        </div>

        {/* Helpful Links */}
        <div className="mt-12 pt-12 border-t border-dark-border">
          <p className="text-sm text-dark-text-muted mb-4">Looking for something specific?</p>
          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <Link href="/docs" className="text-dark-text-secondary hover:text-white transition-colors">
              Documentation
            </Link>
            <Link href="/showcase" className="text-dark-text-secondary hover:text-white transition-colors">
              Showcase
            </Link>
            <Link href="/pricing" className="text-dark-text-secondary hover:text-white transition-colors">
              Pricing
            </Link>
            <Link href="/blog" className="text-dark-text-secondary hover:text-white transition-colors">
              Blog
            </Link>
            <Link href="/contact" className="text-dark-text-secondary hover:text-white transition-colors">
              Contact
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
