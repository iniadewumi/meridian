interface FeatureProps {
  title: string
  description: string
  icon: React.ReactNode
}

const features: FeatureProps[] = [
  {
    title: 'Superior Developer Experience',
    description: 'Built-in TypeScript, hot reload, and intuitive APIs that let you ship faster without compromising quality.',
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
      </svg>
    ),
  },
  {
    title: 'Battle-Tested in Production',
    description: 'Powers thousands of applications serving millions of users. Scale with confidence from day one.',
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    ),
  },
  {
    title: 'Enterprise Ready',
    description: 'Built-in security, monitoring, and compliance features. SOC 2 certified with 99.99% SLA.',
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
      </svg>
    ),
  },
]

function FeatureCard({ title, description, icon }: FeatureProps) {
  return (
    <div className="space-y-4">
      <div className="w-12 h-12 rounded-lg bg-[#111] border border-[#222] flex items-center justify-center text-white">
        {icon}
      </div>
      <h3 className="text-xl font-bold tracking-tight">{title}</h3>
      <p className="text-[#888] leading-relaxed">{description}</p>
    </div>
  )
}

export default function FeatureGrid() {
  return (
    <section className="py-20 px-6 bg-[#111]">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold tracking-tight mb-4">
            Everything You Need
          </h2>
          <p className="text-lg text-[#888] max-w-2xl mx-auto">
            A powerful platform for building modern applications with confidence
          </p>
        </div>

        {/* Feature grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {features.map((feature) => (
            <FeatureCard key={feature.title} {...feature} />
          ))}
        </div>
      </div>
    </section>
  )
}
